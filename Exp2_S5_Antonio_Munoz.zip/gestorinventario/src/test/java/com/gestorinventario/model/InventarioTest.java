package com.gestorinventario.model;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class InventarioTest {
    private Inventario inventario;
    private Producto producto1;
    private Producto producto2;

    @BeforeEach
    void setUp() {
        inventario = new Inventario();
        producto1 = new Producto("1", "Teclado Mecanico", "RGB", 85.00, 10);
        producto2 = new Producto("2", "Mouse Inalambrico", "Ergonomico", 45.50, 20);
    }

    @Test
    void testAgregarProducto() {
        // Prueba: Asegurar que un producto se agrega correctamente.
        inventario.agregarProducto(producto1);
        assertEquals(1, inventario.getTamanoInventario());
        assertNotNull(inventario.getProducto("1"));
        assertEquals("Teclado Mecanico", inventario.getProducto("1").getNombre());
    }

    @Test
    void testAgregarProductoNulo() {
        // Prueba: Probar agregar un producto nulo y asegurar que no se añada.
        inventario.agregarProducto(null);
        assertEquals(0, inventario.getTamanoInventario());
    }

    @Test
    void testEliminarProductoExistente() {
        // Prueba: Confirmar que la eliminación de un producto existente funcione.
        inventario.agregarProducto(producto1);
        inventario.eliminarProducto("1");
        assertEquals(0, inventario.getTamanoInventario());
        assertNull(inventario.getProducto("1"));
    }

    @Test
    void testEliminarProductoInexistente() {
        // Prueba: Intentar eliminar un producto con un ID inexistente.
        inventario.agregarProducto(producto1);
        inventario.eliminarProducto("999");
        assertEquals(1, inventario.getTamanoInventario());
    }

    @Test
    void testBuscarProductoPorNombre() {
        // Prueba: Verificar que la búsqueda por nombre retorna los productos correctos.
        inventario.agregarProducto(producto1);
        inventario.agregarProducto(producto2);
        
        List<Producto> resultados = inventario.buscarPorNombre("Teclado");
        assertEquals(1, resultados.size());
        assertEquals("Teclado Mecanico", resultados.get(0).getNombre());

        resultados = inventario.buscarPorNombre("mouse");
        assertEquals(1, resultados.size());
        assertEquals("Mouse Inalambrico", resultados.get(0).getNombre());
    }

    @Test
    void testBuscarNombreInexistente() {
        // Prueba: Realizar una búsqueda con un nombre que no existe.
        inventario.agregarProducto(producto1);
        List<Producto> resultados = inventario.buscarPorNombre("Monitor");
        assertTrue(resultados.isEmpty());
    }

    @Test
    void testListarTodosLosProductos() {
        // Prueba: Asegurar que el listado contenga todos los productos agregados.
        inventario.agregarProducto(producto1);
        inventario.agregarProducto(producto2);
        
        // La lista devuelta debería tener 2 productos
        // Aunque el método `listarProductos` no devuelve una lista, podemos verificar
        // el estado del inventario a través de su tamaño para esta prueba.
        assertEquals(2, inventario.getTamanoInventario());
    }
}
