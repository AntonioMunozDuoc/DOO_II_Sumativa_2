package com.gestorinventario.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProductoTest {
    private Producto producto;

    @BeforeEach
    void setUp() {
        producto = new Producto("P001", "Laptop", "Laptop de 15 pulgadas", 1200.50, 50);
    }

    @Test
    void testCreacionDeProducto() {
        assertNotNull(producto);
        assertEquals("P001", producto.getId());
        assertEquals("Laptop", producto.getNombre());
        assertEquals("Laptop de 15 pulgadas", producto.getDescripcion());
        assertEquals(1200.50, producto.getPrecio(), 0.01);
        assertEquals(50, producto.getCantidadEnStock());
    }

    @Test
    void testActualizacionDeAtributos() {
        producto.setNombre("Desktop PC");
        assertEquals("Desktop PC", producto.getNombre());

        producto.actualizarPrecio(1500.75);
        assertEquals(1500.75, producto.getPrecio(), 0.01);

        producto.setCantidadEnStock(45);
        assertEquals(45, producto.getCantidadEnStock());
    }

    @Test
    void testActualizarPrecioConValorNegativo() {
        double precioInicial = producto.getPrecio();
        producto.actualizarPrecio(-100.0);
        assertEquals(precioInicial, producto.getPrecio(), 0.01);
    }
}