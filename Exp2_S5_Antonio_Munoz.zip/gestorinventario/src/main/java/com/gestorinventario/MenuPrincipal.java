package com.gestorinventario;

import com.gestorinventario.model.Inventario;
import com.gestorinventario.model.Producto;
import java.util.Scanner;
import java.util.List;

public class MenuPrincipal {
    private Inventario inventario;
    private Scanner scanner;

    public MenuPrincipal() {
        this.inventario = new Inventario();
        this.scanner = new Scanner(System.in);
    }

    public void iniciar() {
        int opcion = -1;
        do {
            mostrarMenu();
            try {
                opcion = Integer.parseInt(scanner.nextLine());
                manejarOpcion(opcion);
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número válido.");
            }
        } while (opcion != 0);
    }

    private void mostrarMenu() {
        System.out.println("\n--- Sistema de Gestión de Inventario ---");
        System.out.println("1. Agregar Producto");
        System.out.println("2. Eliminar Producto");
        System.out.println("3. Buscar Producto por nombre");
        System.out.println("4. Listar todos los productos");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }

    private void manejarOpcion(int opcion) {
        switch (opcion) {
            case 1:
                agregarProducto();
                break;
            case 2:
                eliminarProducto();
                break;
            case 3:
                buscarProducto();
                break;
            case 4:
                inventario.listarProductos();
                break;
            case 0:
                System.out.println("Saliendo del sistema. ¡Adiós!");
                break;
            default:
                System.out.println("Opción no válida. Por favor, intente de nuevo.");
                break;
        }
    }

    private void agregarProducto() {
        System.out.print("ID del producto: ");
        String id = scanner.nextLine();
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        System.out.print("Precio: ");
        double precio = Double.parseDouble(scanner.nextLine());
        System.out.print("Cantidad en stock: ");
        int stock = Integer.parseInt(scanner.nextLine());

        Producto nuevoProducto = new Producto(id, nombre, descripcion, precio, stock);
        inventario.agregarProducto(nuevoProducto);
    }

    private void eliminarProducto() {
        System.out.print("Ingrese el ID del producto a eliminar: ");
        String id = scanner.nextLine();
        inventario.eliminarProducto(id);
    }

    private void buscarProducto() {
        System.out.print("Ingrese el nombre a buscar: ");
        String nombre = scanner.nextLine();
        List<Producto> resultados = inventario.buscarPorNombre(nombre);
        if (resultados.isEmpty()) {
            System.out.println("No se encontraron productos con ese nombre.");
        } else {
            System.out.println("--- Resultados de la Búsqueda ---");
            for (Producto p : resultados) {
                System.out.println(p);
            }
            System.out.println("----------------------------------");
        }
    }

    public static void main(String[] args) {
        MenuPrincipal app = new MenuPrincipal();
        app.iniciar();
    }
}