package com.gestorinventario;

// Importamos la clase MenuPrincipal para poder usarla en este archivo
import com.gestorinventario.MenuPrincipal;

/**
 * Clase principal de la aplicación.
 * Sirve como el punto de entrada del programa.
 */
public class Gestorinventario {

    /**
     * @param args los argumentos de la línea de comandos.
     */
    
    public static void main(String[] args) {
        // Creamos una instancia de la clase MenuPrincipal
        MenuPrincipal app = new MenuPrincipal();

        // Llamamos al método iniciar() para arrancar la aplicación
        app.iniciar();
    }
}