package com.gestorinventario.model;

import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

public class Inventario {
    private Map<String, Producto> productos;

    public Inventario() {
        productos = new HashMap<>();
    }

    // Método para agregar productos
    public void agregarProducto(Producto producto) {
        if (producto != null && producto.getId() != null) {
            productos.put(producto.getId(), producto);
            System.out.println("Producto agregado: " + producto.getNombre());
        }
    }

    // Método para eliminar productos
    public void eliminarProducto(String id) {
        if (productos.remove(id) != null) {
            System.out.println("Producto con ID " + id + " eliminado.");
        } else {
            System.out.println("No se encontró ningún producto con ID " + id);
        }
    }
    
    // Método para buscar productos por nombre o descripción
    public List<Producto> buscarPorNombre(String nombre) {
        List<Producto> resultados = new ArrayList<>();
        for (Producto producto : productos.values()) {
            if (producto.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                resultados.add(producto);
            }
        }
        return resultados;
    }

    // Método para listar todos los productos
    public void listarProductos() {
        if (productos.isEmpty()) {
            System.out.println("El inventario está vacío.");
        } else {
            System.out.println("--- Inventario Actual ---");
            for (Producto producto : productos.values()) {
                System.out.println(producto.toString());
            }
            System.out.println("-------------------------");
        }
    }
    
    // Método para obtener un producto por su ID (útil para pruebas)
    public Producto getProducto(String id) {
        return productos.get(id);
    }
    
    // Método para obtener el tamaño del inventario (útil para pruebas)
    public int getTamanoInventario() {
        return productos.size();
    }
}